﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CacaNiquel
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void btnTemp_Click(object sender, EventArgs e)
        {
            // Ao clicar no botão temperatura, abre o formulário de temperatura
            frmTemperatura frmTemperatura = new frmTemperatura();
            frmTemperatura.ShowDialog(); // abre o formulário como um diálogo
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            frmMedia media = new frmMedia();
            media.Show();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult resp;
            resp = MessageBox.Show("Deseja realmente sair da aplicação?", "Cálculo da Temperatura", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resp == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
