﻿namespace aula
{
    partial class CacaNiquel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CacaNiquel));
            this.lblniquel1 = new System.Windows.Forms.Label();
            this.btnGirar = new System.Windows.Forms.Button();
            this.lblniquel2 = new System.Windows.Forms.Label();
            this.lblniquel3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tmrSorteioGeral = new System.Windows.Forms.Timer(this.components);
            this.btnJogar = new System.Windows.Forms.Button();
            this.tmrJogar = new System.Windows.Forms.Timer(this.components);
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.lbllista = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lblniquel1
            // 
            this.lblniquel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblniquel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblniquel1.Location = new System.Drawing.Point(12, 62);
            this.lblniquel1.Name = "lblniquel1";
            this.lblniquel1.Size = new System.Drawing.Size(76, 91);
            this.lblniquel1.TabIndex = 0;
            this.lblniquel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGirar
            // 
            this.btnGirar.BackColor = System.Drawing.SystemColors.Control;
            this.btnGirar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGirar.Location = new System.Drawing.Point(127, 242);
            this.btnGirar.Name = "btnGirar";
            this.btnGirar.Size = new System.Drawing.Size(73, 44);
            this.btnGirar.TabIndex = 3;
            this.btnGirar.Text = "GIRAR";
            this.btnGirar.UseVisualStyleBackColor = false;
            this.btnGirar.Click += new System.EventHandler(this.btnGirar_Click);
            // 
            // lblniquel2
            // 
            this.lblniquel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblniquel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblniquel2.Location = new System.Drawing.Point(122, 62);
            this.lblniquel2.Name = "lblniquel2";
            this.lblniquel2.Size = new System.Drawing.Size(76, 91);
            this.lblniquel2.TabIndex = 4;
            this.lblniquel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblniquel2.Click += new System.EventHandler(this.lblniquel2_Click);
            // 
            // lblniquel3
            // 
            this.lblniquel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lblniquel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblniquel3.Location = new System.Drawing.Point(233, 62);
            this.lblniquel3.Name = "lblniquel3";
            this.lblniquel3.Size = new System.Drawing.Size(76, 91);
            this.lblniquel3.TabIndex = 5;
            this.lblniquel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Vineta BT", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.label4.Location = new System.Drawing.Point(56, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(204, 32);
            this.label4.TabIndex = 6;
            this.label4.Text = "CAÇA  NIQUEL";
            // 
            // tmrSorteioGeral
            // 
            this.tmrSorteioGeral.Interval = 500;
            this.tmrSorteioGeral.Tick += new System.EventHandler(this.tmrSorteioGeral_Tick);
            // 
            // btnJogar
            // 
            this.btnJogar.BackColor = System.Drawing.SystemColors.Control;
            this.btnJogar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJogar.Location = new System.Drawing.Point(113, 176);
            this.btnJogar.Name = "btnJogar";
            this.btnJogar.Size = new System.Drawing.Size(99, 60);
            this.btnJogar.TabIndex = 7;
            this.btnJogar.Text = "jogar";
            this.btnJogar.UseVisualStyleBackColor = false;
            this.btnJogar.Click += new System.EventHandler(this.btnJogar_Click);
            // 
            // tmrJogar
            // 
            this.tmrJogar.Interval = 300;
            this.tmrJogar.Tick += new System.EventHandler(this.tmrJogar_Tick);
            // 
            // lbllista
            // 
            this.lbllista.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbllista.FormattingEnabled = true;
            this.lbllista.Items.AddRange(new object[] {
            "Lata",
            "Fruta",
            "Arroz"});
            this.lbllista.Location = new System.Drawing.Point(12, 328);
            this.lbllista.Name = "lbllista";
            this.lbllista.Size = new System.Drawing.Size(141, 199);
            this.lbllista.TabIndex = 9;
            this.lbllista.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // CacaNiquel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(336, 551);
            this.Controls.Add(this.lbllista);
            this.Controls.Add(this.btnJogar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblniquel3);
            this.Controls.Add(this.lblniquel2);
            this.Controls.Add(this.btnGirar);
            this.Controls.Add(this.lblniquel1);
            this.Name = "CacaNiquel";
            this.Text = "cacaNiquel";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblniquel1;
        private System.Windows.Forms.Button btnGirar;
        private System.Windows.Forms.Label lblniquel2;
        private System.Windows.Forms.Label lblniquel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer tmrSorteioGeral;
        private System.Windows.Forms.Button btnJogar;
        private System.Windows.Forms.Timer tmrJogar;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ListBox lbllista;
    }
}

