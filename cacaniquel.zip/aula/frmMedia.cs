﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CacaNiquel
{
    public partial class frmMedia : Form
    {

        public frmMedia()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult resp;
            resp = MessageBox.Show("Deseja realmente sair da aplicação?", "Cálculo da Média", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resp == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double nota1 = double.Parse(txtNota1.Text);
                double nota2 = double.Parse(txtNota2.Text);
                double nota3 = double.Parse(txtNota3.Text);

                double media = (nota1 + nota2 + nota3) / 3;

                lblResultado.Text = "Média: " + media.ToString("F2");
            }
            catch
            {
                MessageBox.Show("Digite valores válidos para as notas.");
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

            txtNota1.Update();
            txtNota2.Update();
            txtNota3.Update();
            lblResultado.Text = "Média: ";



        }
    }
}
