﻿namespace aula
{
    partial class frmMegaSena
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMegaSena));
            this.SortearNum = new System.Windows.Forms.Button();
            this.lbl = new System.Windows.Forms.Label();
            this.lstCartoes = new System.Windows.Forms.ListBox();
            this.QtdeCartoes = new System.Windows.Forms.TextBox();
            this.lblNumeros = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // SortearNum
            // 
            this.SortearNum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.SortearNum.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SortearNum.Location = new System.Drawing.Point(138, 385);
            this.SortearNum.Name = "SortearNum";
            this.SortearNum.Size = new System.Drawing.Size(107, 38);
            this.SortearNum.TabIndex = 1;
            this.SortearNum.Text = "Sortear Numeros";
            this.SortearNum.UseVisualStyleBackColor = false;
            this.SortearNum.Click += new System.EventHandler(this.SortearNum_Click);
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lbl.Font = new System.Drawing.Font("Palatino Linotype", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl.Location = new System.Drawing.Point(29, 72);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(150, 19);
            this.lbl.TabIndex = 2;
            this.lbl.Text = "Quantidade de cartões";
            // 
            // lstCartoes
            // 
            this.lstCartoes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.lstCartoes.Font = new System.Drawing.Font("Consolas", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstCartoes.FormattingEnabled = true;
            this.lstCartoes.ItemHeight = 22;
            this.lstCartoes.Location = new System.Drawing.Point(33, 191);
            this.lstCartoes.Name = "lstCartoes";
            this.lstCartoes.Size = new System.Drawing.Size(328, 180);
            this.lstCartoes.TabIndex = 5;
            // 
            // QtdeCartoes
            // 
            this.QtdeCartoes.Location = new System.Drawing.Point(185, 71);
            this.QtdeCartoes.Name = "QtdeCartoes";
            this.QtdeCartoes.Size = new System.Drawing.Size(100, 20);
            this.QtdeCartoes.TabIndex = 6;
            this.QtdeCartoes.TextChanged += new System.EventHandler(this.QtdeCartoes_TextChanged);
            // 
            // lblNumeros
            // 
            this.lblNumeros.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblNumeros.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumeros.Font = new System.Drawing.Font("MingLiU-ExtB", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumeros.Location = new System.Drawing.Point(12, 112);
            this.lblNumeros.Name = "lblNumeros";
            this.lblNumeros.Size = new System.Drawing.Size(370, 59);
            this.lblNumeros.TabIndex = 0;
            // 
            // frmMegaSena
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(394, 561);
            this.Controls.Add(this.QtdeCartoes);
            this.Controls.Add(this.lstCartoes);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.SortearNum);
            this.Controls.Add(this.lblNumeros);
            this.Name = "frmMegaSena";
            this.Text = "frmMegaSena";
            this.Load += new System.EventHandler(this.frmMegaSena_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button SortearNum;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.ListBox lstCartoes;
        private System.Windows.Forms.TextBox QtdeCartoes;
        private System.Windows.Forms.Label lblNumeros;
    }
}