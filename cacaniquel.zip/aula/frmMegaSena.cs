﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aula
{
    public partial class frmMegaSena : Form
    {
        // 04 - Giovanna de Oliveira e 22 - Renan Tiago
        // Início da Classe - Criação de variáveis, objetos, tipos que serão privados

        private Random sorteio = new Random(); // Sorteio.Next(1,50) - sorteia um número entre 1 e 50
        private int numeroSorteado;
        private int[,] cartao; // Array de inteiros, duas dimensões
        private char[,] jogoVelha = new char[,] {

            { 'X','O', 'X' },
            { 'O', 'X', 'O' },
            { 'X', 'O', 'X' } };

        private object numerosCartao;

        public frmMegaSena()
        {
            InitializeComponent();
        }

        private void SortearNum_Click(object sender, EventArgs e)
        {
            // Consistência de dados - verificar quantidade de cartelas
            if (String.IsNullOrWhiteSpace(QtdeCartoes.Text))
            {
                MessageBox.Show("Informe a quantidade de cartões a serem gerados!!", "Mega sena", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            cartao = new int[Convert.ToInt32(QtdeCartoes.Text), 6]; // Criar o array de cartelas
            GerarCartao();
        }

        private void GerarCartao()
        {
            lblNumeros.Text = ""; // Garantir que começa vazio

            for (int i = 0; i < Convert.ToInt32(QtdeCartoes.Text); i++)
            {


                // Usando o metodo hashset garantir que não terá números repetidos na cartela
                HashSet<int> numerosSorteados = new HashSet<int>();

         
                for (int j = 0; j < 6; j++)
                {
                    do
                    {
                        numeroSorteado = sorteio.Next(1, 61); // Sorteio de números entre 1 e 60

                    } while (!numerosSorteados.Add(numeroSorteado)); // Tenta adicionar ao HashSet e garante que o número seja único

                    cartao[i, j] = numeroSorteado;
                }

                // Aplicando o Bubble Sort para ordenar os números da cartela

                BubbleSort(cartao, i);

                // Adicionando os números sorteados na label para exibir
                for (int j = 0; j < 6; j++)
                {
                    lblNumeros.Text += cartao[i, j].ToString("00") + " - ";
                }

               
                if (lblNumeros.Text.EndsWith(" - "))
                {
                    lblNumeros.Text = lblNumeros.Text.Substring(0, lblNumeros.Text.Length - 3); // metodo pra tirar o hifen no final
                }

                lstCartoes.Items.Add(lblNumeros.Text);
                lblNumeros.Text = ""; // Limpar para a próxima cartela
            }
        }

        // Método Bubble Sort para ordenar a cartela
        private void BubbleSort(int[,] cartao, int linha)
        {
            int temp;
            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 6 - 1; j++)
                {
                    if (cartao[linha, j] > cartao[linha, j + 1]) // Se o número da esquerda for maior que o da direita, ele troca
                    {
                        temp = cartao[linha, j];
                        cartao[linha, j] = cartao[linha, j + 1];
                        cartao[linha, j + 1] = temp;
                    }
                }
            }
        }

        private void frmMegaSena_Load(object sender, EventArgs e)
        {
           
        }

        private void QtdeCartoes_TextChanged(object sender, EventArgs e)
        {
          
        }
    }
}


