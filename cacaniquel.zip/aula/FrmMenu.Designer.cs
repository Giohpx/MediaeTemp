﻿namespace CacaNiquel
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMenu));
            this.btnTemp = new System.Windows.Forms.Button();
            this.btnMedia = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnTemp
            // 
            this.btnTemp.AutoSize = true;
            this.btnTemp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnTemp.BackgroundImage")));
            this.btnTemp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnTemp.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnTemp.Location = new System.Drawing.Point(21, 57);
            this.btnTemp.Name = "btnTemp";
            this.btnTemp.Size = new System.Drawing.Size(176, 170);
            this.btnTemp.TabIndex = 0;
            this.btnTemp.Text = "Temperatura";
            this.btnTemp.UseVisualStyleBackColor = true;
            this.btnTemp.Click += new System.EventHandler(this.btnTemp_Click);
            // 
            // btnMedia
            // 
            this.btnMedia.BackColor = System.Drawing.SystemColors.Control;
            this.btnMedia.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMedia.BackgroundImage")));
            this.btnMedia.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnMedia.Location = new System.Drawing.Point(265, 57);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(175, 170);
            this.btnMedia.TabIndex = 1;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = false;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(189, 278);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(82, 42);
            this.btnSair.TabIndex = 2;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // FrmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 372);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnMedia);
            this.Controls.Add(this.btnTemp);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmMenu";
            this.Text = "Menu de Aplicações 1.0";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnTemp;
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Button btnSair;
    }
}