﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace aula
{
    public partial class CacaNiquel : Form
    {

        // 04 - Giovanna de Oliveira e 22 - Renan Tiago

        private Random sorteio = new Random();
        private int niquel1, niquel2, niquel3;
        private int contaGiro = 0;
        private int contaNiquel = 0;
        public CacaNiquel()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void btnGirar_Click(object sender, EventArgs e)
        {
            MostrarNiquel();
        }

        private void btnJogar_Click(object sender, EventArgs e)
        {
            btnJogar.Text = " $stop";
            tmrJogar.Enabled = true;


        }

        private void tmrJogar_Tick(object sender, EventArgs e)
        {   
                contaGiro++;

                if (contaNiquel == 0)
                {
                    niquel1 = sorteio.Next(0, 10);
                    lblniquel1.Text = niquel1.ToString();
                }

                else if (contaNiquel == 1)
                {
                    niquel2 = sorteio.Next(0, 10);
                    lblniquel2.Text = niquel2.ToString();
                }
                else if (contaNiquel == 2)
                {
                    niquel3 = sorteio.Next(0, 10);
                    lblniquel3.Text = niquel3.ToString();
                }
                else
                {
                    //atingiu a condição de término

                    tmrJogar.Enabled = false;
                    MessageBox.Show("Parabens pela conquista!!! \n\n" + " Sequencia: " + niquel1.ToString() + " - " + niquel2.ToString() + " - " + niquel3.ToString() + " Jogador Wins!! " + MessageBoxButtons.OK + MessageBoxIcon.Exclamation);
                    lblniquel1.Text = String.Empty;
                    lblniquel2.Text = String.Empty;
                    lblniquel3.Text = String.Empty;
                    btnJogar.Text = "$Jogar";
                    contaGiro = 0;

                if (niquel1 == niquel2 && niquel2 == niquel3 && niquel1 == niquel3)
                {
                    MessageBox.Show("Ganhou 1 milhão de reais!!");
                    lbllista.Items.Add(niquel1.ToString() + " - " + niquel2.ToString() + " - " + niquel3.ToString());
                    return;
                }
                else if (niquel1 == niquel2 || niquel1 == niquel3 || niquel2 == niquel3)
                {
                    MessageBox.Show("Ganhou meio milhão de reais!!");
                    return;
                }
                else
                {
                    MessageBox.Show("Perdeu tudo!!");
                    return;

                }
                }

                if (contaGiro == 10)
                {
                    contaNiquel++;
                    contaGiro = 0;
                }

                return;

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblniquel2_Click(object sender, EventArgs e)
        {

        }

        private void MostrarNiquel()
        {
            niquel1 = sorteio.Next(0, 10);
            niquel2 = sorteio.Next(0, 10);
            niquel3 = sorteio.Next(0, 10);

            lblniquel1.Text = niquel1.ToString();
            lblniquel2.Text = niquel2.ToString();
            lblniquel3.Text = niquel3.ToString();

            if (niquel1 == niquel2 && niquel2 == niquel3 && niquel1 == niquel3)
            {
                MessageBox.Show("Ganhou!!!");
            }
            else if (niquel1 == niquel2 || niquel1 == niquel3 || niquel2 == niquel3)
            {
                MessageBox.Show("Ganhou meio milhão de reais!!");
            }
            else
            {
                MessageBox.Show("Perdeu tudo!!");
                return;
            }

        }

        private void tmrSorteioGeral_Tick(object sender, EventArgs e)
        {
            MostrarNiquel();
           
        }

        
    }
}
