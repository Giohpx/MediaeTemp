﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CacaNiquel
{
    public partial class frmTemperatura : Form
    {
      
        public frmTemperatura()
        {
            InitializeComponent();
        }

        private decimal AcrescimoPercentual(decimal tempetura, decimal percAcrescimo)
        {
            decimal novaTemp = 0;
            novaTemp = tempetura + tempetura * percAcrescimo / 100;
            return novaTemp;
        }

        private void Calcular_Click(object sender, EventArgs e)
        {
            decimal novaTemp = 0;
            novaTemp = AcrescimoPercentual(numTemperatura.Value, numPercentualAcrescimo.Value);
            lblResultado.Text = novaTemp.ToString("#0.00");
            btnNovo.Focus();

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            numTemperatura.Value = 0;
            numPercentualAcrescimo.Value = 0;
            lblResultado.Text = null;
            numTemperatura.Focus();
        }

        

        private void btnSair_Click_1(object sender, EventArgs e)
        {
            DialogResult resp;
            resp = MessageBox.Show("Deseja realmente sair da aplicação?", "Cálculo da Temperatura", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (resp == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
